cd ./consumet-api && npm start
