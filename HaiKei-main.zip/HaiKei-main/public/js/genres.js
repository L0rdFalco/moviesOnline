function toggle() {
    window.location.href = `/genre/${genre}`
}