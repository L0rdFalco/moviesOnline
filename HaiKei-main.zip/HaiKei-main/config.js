const config = {
 app: {
   port: 3000,
   api_url3: 'https://api.haikei.xyz/',
 },
};

module.exports = config;